#ifndef __IOKIT_IOKITINTERNAL_H
#define __IOKIT_IOKITINTERNAL_H

#include <CoreFoundation/CFBase.h>

#define thread_errno() errno

#define CFMaxPathSize ((CFIndex)1026)
#define CFMaxPathLength ((CFIndex)1024)

#endif /* __IOKIT_IOKITINTERNAL_H */
